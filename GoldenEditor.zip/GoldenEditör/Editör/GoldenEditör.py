#!/usr/bin/env python3
"""
GOLDEN EDİTÖR  —  Golden programlama dili (.gld) + siyah-sarı kod editörü
Gereken tek şey: Python 3 (tkinter dahil). Çalıştır:  python golden_editor.py
"""
import codecs, math, os, queue, random, re, subprocess, sys, tempfile, threading, time, traceback
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import tkinter.font as tkfont

# ============================================================ GOLDEN DİLİ
class GoldenError(Exception):
    def __init__(self, msg, line):
        super().__init__(msg)
        self.line = line

WORD_MAP = {"ve": "and", "veya": "or", "değil": "not", "doğru": "True",
            "yanlış": "False", "boş": "None", "içinde": "in"}
TOKEN = re.compile(r'''("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|([^\W\d]\w*)''')
CMD_FUNCS = {"bekle", "temizle", "bip", "çık", "pencere", "göster", "mesaj"}
WIDGETS = {"etiket", "düğme", "giriş", "metinalanı", "onay", "kaydırıcı", "listekutusu"}
NAME_CMDS = {"ayarla", "renk", "ekle"}


def tr_expr(s):
    return TOKEN.sub(lambda m: m.group(1) or WORD_MAP.get(m.group(2), m.group(2)), s)


def cond(s):
    return tr_expr(re.sub(r"\s+ise$", "", s.strip()))


def strip_comment(line):
    q, i = None, 0
    while i < len(line):
        c = line[i]
        if q:
            if c == "\\":
                i += 1
            elif c == q:
                q = None
        elif c in "\"'":
            q = c
        elif c == "#":
            return line[:i]
        i += 1
    return line


def transpile(src):
    """Golden -> Python (satır sayısı korunur, hata satırları birebir eşleşir)."""
    out, stack = [], []
    E = tr_expr
    for no, raw in enumerate(src.split("\n"), 1):
        line = strip_comment(raw).strip()
        if not line:
            out.append("")
            continue
        p = line.split(None, 1)
        w, r = p[0], (p[1].strip() if len(p) > 1 else "")
        ind, opens = len(stack), False
        if w == "bitir":
            if not stack:
                raise GoldenError("fazladan 'bitir'", no)
            stack.pop()
            py, ind = "pass", len(stack)
        elif w in ("değilse", "yoksa", "hata", "sonunda"):
            if not stack:
                raise GoldenError("'" + w + "' bir blok içinde olmalı", no)
            ind -= 1
            if w == "yoksa" and r.startswith("eğer"):
                py = "elif " + cond(r[4:]) + ":"
            elif w in ("değilse", "yoksa") and not r:
                py = "else:"
            elif w == "hata":
                py = "except Exception as " + (r or "_hata") + ":"
            elif w == "sonunda":
                py = "finally:"
            else:
                raise GoldenError("anlaşılmayan ifade: " + line, no)
        elif w == "eğer":
            py, opens = "if " + cond(r) + ":", True
        elif w == "iken":
            py, opens = "while " + cond(r) + ":", True
        elif w == "tekrarla":
            py, opens = "for _ in range(int(" + E(r) + ")):", True
        elif w == "döngü":
            m = re.match(r"(\w+)\s+(.+?)\s+den\s+(.+?)\s+kadar(?:\s+adım\s+(.+))?$", r)
            if not m:
                raise GoldenError("kullanım: döngü i 1 den 10 kadar [adım 2]", no)
            py, opens = "for %s in _aralık(%s, %s, %s):" % (m[1], E(m[2]), E(m[3]), E(m[4] or "1")), True
        elif w == "her":
            m = re.match(r"(\w+)\s+içinde\s+(.+)$", r)
            if not m:
                raise GoldenError("kullanım: her öge içinde liste", no)
            py, opens = "for %s in %s:" % (m[1], E(m[2])), True
        elif w == "fonksiyon":
            if "(" in r:
                py = "def " + E(r) + ":"
            else:
                n = r.split()
                if not n:
                    raise GoldenError("fonksiyon adı eksik", no)
                py = "def %s(%s):" % (n[0], ", ".join(n[1:]))
            opens = True
        elif w == "sınıf":
            py, opens = "class " + r + ":", True
        elif w == "dene":
            py, opens = "try:", True
        elif w == "satır":
            py, opens = "with _satır():", True
        elif w == "düğme" and re.match(r"\w+\s+.+?\s+\w+$", r):
            m = re.match(r"(\w+)\s+(.+?)\s+(\w+)$", r)
            py = "%s = düğme(%s, lambda: %s())" % (m[1], E(m[2]), m[3])
        elif w == "zamanlayıcı":
            m = re.match(r"(.+?)\s+(\w+)$", r)
            if not m:
                raise GoldenError("kullanım: zamanlayıcı 1000 işlev", no)
            py = "zamanlayıcı(%s, lambda: %s())" % (E(m[1]), m[2])
        elif (w in WIDGETS or w in NAME_CMDS) and r and not r.startswith(("(", "=")):
            m = re.match(r"(\w+)\s*,?\s*(.*)$", r)
            if not m:
                raise GoldenError("kullanım: %s ad ..." % w, no)
            py = ("%s = %s(%s)" if w in WIDGETS else "%s(%s, %s)") % ((m[1], w, E(m[2])) if w in WIDGETS else (w, m[1], E(m[2])))
        elif w == "yaz":
            py = "print(" + E(r) + ")"
        elif w in ("oku", "sayıoku"):
            n, _, q = r.partition(" ")
            if not n:
                raise GoldenError('kullanım: %s değişken "soru"' % w, no)
            py = "%s = %s(%s)" % (n, "girdi" if w == "oku" else "sayıoku", E(q))
        elif w == "döndür":
            py = ("return " + E(r)).strip()
        elif w == "kır":
            py = "break"
        elif w == "devam":
            py = "continue"
        elif w == "içe_al":
            py = "import " + r
        elif w == "değer":
            py = E(r)
        elif w in CMD_FUNCS and not r.startswith(("(", "=")):
            py = w + "(" + E(r) + ")"
        else:
            py = E(line)
        out.append("    " * ind + py)
        if opens:
            stack.append(no)
    if stack:
        raise GoldenError("bu blok 'bitir' ile kapatılmamış", stack[-1])
    return "\n".join(out)


class _GUI:
    def __init__(self):
        self.root, self.stack, self.shown = None, [], False

    def ensure(self):
        if not self.root:
            self.root = tk.Tk()
            self.root.configure(bg=BG)
            self.root.title("Golden Uygulama")
            self.root.geometry("420x360")
            self.root.report_callback_exception = lambda t, v, tb: rapor(v)
            self.root.bind_all("<Button-1>", self.birak, add="+")
            self.stack = [(self.root, False)]
        return self.root

    def birak(self, e):
        """Yazı girilen bileşenlerin dışına tıklanınca odağı bırak (ipucu geri gelebilsin)."""
        w = e.widget
        if isinstance(w, (tk.Text, tk.Entry, tk.Listbox, tk.Scale)) or hasattr(w, "_sahip"):
            return
        try:
            w.winfo_toplevel().focus_set()
        except Exception:
            pass

    def finish(self):
        if self.root and not self.shown:
            self.shown = True
            self.root.mainloop()


def gui_env():
    G = _GUI()

    def P():
        G.ensure()
        return G.stack[-1][0]

    def koy(w):
        if G.stack[-1][1]:
            w.pack(side="left", padx=4, pady=4)
        else:
            w.pack(fill="x", padx=14, pady=5)
        return w

    class _satır:
        def __enter__(s):
            f = koy(tk.Frame(P(), bg=BG))
            G.stack.append((f, True))

        def __exit__(s, *a):
            G.stack.pop()

    def pencere(başlık="Golden Uygulama", en=420, boy=360):
        G.ensure().title(str(başlık))
        G.root.geometry("%dx%d" % (en, boy))

    def göster():
        G.ensure()
        G.shown = True
        G.root.mainloop()

    def etiket(m=""):
        return koy(tk.Label(P(), text=str(m), bg=BG, fg=TEXT, font=("Segoe UI", 11), anchor="w"))

    def düğme(m="", işlev=None):
        return koy(tk.Button(P(), text=str(m), command=işlev, bg=GOLD, fg="#000", activebackground="#FFD84D",
                             relief="flat", borderwidth=0, padx=14, pady=5, cursor="hand2",
                             font=("Segoe UI", 10, "bold")))

    def ipucu_ekle(w, ipucu, x):
        """Placeholder: kutu boşken ve odakta değilken açık gri görünür; tıklayınca/yazınca kaybolur."""
        if not ipucu:
            return w
        ph = tk.Label(w, text=str(ipucu), bg=PANEL, fg="#9A9A9A", font=("Segoe UI", 11),
                      borderwidth=0, padx=0, pady=0, cursor="xterm")
        w._ph, w._odak, ph._sahip = ph, False, w

        def upd(*a):
            bos = not (w.get("1.0", "end-1c") if isinstance(w, tk.Text) else w.get())
            if bos and not w._odak:
                if isinstance(w, tk.Text):
                    ph.place(x=x, y=0)
                else:
                    ph.place(x=x, y=-1, rely=0.5, anchor="w")
            else:
                ph.place_forget()

        def odak(v):
            def f(e):
                w._odak = v
                upd()
            return f

        def tikla(e=None):
            w._odak = True
            upd()

        w._upd = upd
        ph.bind("<Button-1>", lambda e: (tikla(), w.focus_set()))
        w.bind("<Button-1>", tikla, add="+")
        w.bind("<Key>", tikla, add="+")
        w.bind("<FocusIn>", odak(True), add="+")
        w.bind("<FocusOut>", odak(False), add="+")
        upd()
        return w

    def giriş(ipucu=""):
        e = tk.Entry(P(), bg=PANEL, fg=GOLD, insertbackground=GOLD, relief="flat", font=("Segoe UI", 11),
                     highlightthickness=1, highlightbackground="#3a3000", highlightcolor=GOLD)
        return koy(ipucu_ekle(e, ipucu, 1))

    def metinalanı(ipucu="", yükseklik=6):
        t = tk.Text(P(), bg=PANEL, fg=TEXT, insertbackground=GOLD, relief="flat", height=yükseklik,
                    font=("Segoe UI", 11), highlightthickness=1, highlightbackground="#3a3000",
                    highlightcolor=GOLD, padx=6, pady=4)
        return koy(ipucu_ekle(t, ipucu, 0))

    def onay(m=""):
        v = tk.BooleanVar()
        c = tk.Checkbutton(P(), text=str(m), variable=v, bg=BG, fg=TEXT, selectcolor=PANEL,
                           activebackground=BG, activeforeground=GOLD, font=("Segoe UI", 11))
        c._v = v
        return koy(c)

    def kaydırıcı(a=0, b=100):
        v = tk.DoubleVar(value=a)
        s = tk.Scale(P(), from_=a, to=b, orient="horizontal", variable=v, bg=BG, fg=GOLD, troughcolor=PANEL,
                     highlightthickness=0, activebackground=GOLD)
        s._v = v
        return koy(s)

    def listekutusu(*öğeler):
        lb = tk.Listbox(P(), bg=PANEL, fg=TEXT, selectbackground=GOLD, selectforeground="#000", height=6,
                        borderwidth=0, highlightthickness=1, highlightbackground="#3a3000", font=("Segoe UI", 11))
        for x in öğeler:
            lb.insert("end", x)
        return koy(lb)

    def ayarla(w, v=""):
        if isinstance(w, tk.Entry):
            w.delete(0, "end")
            w.insert(0, str(v))
        elif isinstance(w, tk.Text):
            w.delete("1.0", "end")
            w.insert("1.0", str(v))
        elif isinstance(w, tk.Listbox):
            w.delete(0, "end")
            for x in v:
                w.insert("end", x)
        elif hasattr(w, "_v"):
            w._v.set(v)
        else:
            w.config(text=str(v))
        if hasattr(w, "_upd"):
            w._upd()

    def al(w):
        if isinstance(w, tk.Entry):
            return w.get()
        if isinstance(w, tk.Text):
            return w.get("1.0", "end-1c")
        if isinstance(w, tk.Listbox):
            s = w.curselection()
            return w.get(s[0]) if s else None
        if hasattr(w, "_v"):
            v = w._v.get()
            return int(v) if isinstance(v, float) and v.is_integer() else v
        return w.cget("text")

    def ekle(w, öğe):
        w.insert("end", öğe)

    def renk(w, yazı, arka=None):
        w.config(fg=yazı)
        if arka:
            w.config(bg=arka)
            if hasattr(w, "_ph"):
                w._ph.config(bg=arka)

    def mesaj(m):
        messagebox.showinfo("Golden", str(m))

    def soru(m):
        return messagebox.askyesno("Golden", str(m))

    def zamanlayıcı(ms, işlev):
        def t():
            işlev()
            G.root.after(int(ms), t)
        G.ensure().after(int(ms), t)

    d = {k: v for k, v in locals().items() if k not in ("G", "d", "P", "koy")}
    d["_G"] = G
    return d



def golden_eposta_gonder(gonderen, hata_metni):
    """Golden hata raporunu Cloudflare API üzerinden kaydeder."""
    import json
    import urllib.request
    import urllib.error

    gonderen = str(gonderen).strip()
    hata_metni = str(hata_metni).strip()

    if not gonderen or not re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", gonderen):
        messagebox.showerror("Golden Hata Bildir", "Geçerli bir e-posta adresi yaz.")
        return False
    if not hata_metni:
        messagebox.showerror("Golden Hata Bildir", "Lütfen hata mesajını yaz.")
        return False
    if len(gonderen) > 254 or len(hata_metni) > 10000:
        messagebox.showerror("Golden Hata Bildir", "E-posta veya hata açıklaması çok uzun.")
        return False

    api_url = "https://crimson-shadow-2c2a.kucukkaan212.workers.dev/"
    payload = json.dumps(
        {"eposta": gonderen, "aciklama": hata_metni},
        ensure_ascii=False
    ).encode("utf-8")
    request = urllib.request.Request(
        api_url,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "GoldenStudio/1.0"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            result = json.loads(response.read().decode("utf-8"))

        if response.status == 200 and result.get("ok") is True:
            messagebox.showinfo("Golden", "Hata bildirimin başarıyla kaydedildi!")
            return True

        messagebox.showerror(
            "Golden Hata Bildir",
            result.get("error", "Rapor kaydedilemedi.")
        )
        return False
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        messagebox.showerror(
            "Golden Hata Bildir",
            f"Sunucu HTTP {error.code} hatası verdi.\n{detail[:400]}"
        )
        return False
    except Exception as error:
        messagebox.showerror(
            "Golden Hata Bildir",
            f"Cloudflare API bağlantı hatası: {type(error).__name__}: {error}"
        )
        return False

def make_env():
    def girdi(p=""):
        print(p, end="", flush=True)
        return sys.stdin.readline().rstrip("\r\n")

    def sayıoku(p=""):
        while True:
            try:
                f = float(girdi(p).replace(",", "."))
                return int(f) if f.is_integer() else f
            except ValueError:
                print("Lütfen geçerli bir sayı gir.")

    def bekle(s=1):
        time.sleep(float(s))

    def temizle():
        print("\f", end="", flush=True)

    def bip():
        try:
            import winsound
            winsound.Beep(880, 150)
        except Exception:
            print("\a", end="", flush=True)

    def çık():
        raise SystemExit

    def dosya_ekle(y, m):
        with open(y, "a", encoding="utf-8") as f:
            f.write(str(m))

    def _aralık(a, b, s=1):
        return range(int(a), int(b) + (1 if s > 0 else -1), int(s))

    env = {
        "__name__": "__golden__", "girdi": girdi, "sayıoku": sayıoku, "bekle": bekle,
        "temizle": temizle, "bip": bip, "çık": çık, "dosya_ekle": dosya_ekle, "_aralık": _aralık,
        "dosya_oku": lambda y: Path(y).read_text("utf-8"),
        "dosya_yaz": lambda y, m: Path(y).write_text(str(m), "utf-8"),
        "uzunluk": len, "rastgele": random.randint, "rastgele_seç": random.choice,
        "karıştır": random.shuffle, "karekök": math.sqrt, "üs": pow, "mutlak": abs,
        "yuvarla": round, "büyük": str.upper, "küçük": str.lower, "metin": str, "tam": int,
        "ondalık": float, "liste": list, "sözlük": dict, "aralık": range, "topla": sum,
        "en_büyük": max, "en_küçük": min, "sırala": sorted, "tür": type, "pi": math.pi,
        "sin": math.sin, "cos": math.cos, "zaman": time.time,
        "tersle": lambda x: list(reversed(x)),
        "böl": lambda m, a=None: m.split(a),
        "birleştir": lambda l, a="": a.join(map(str, l)),
        "tarih": lambda f="%d.%m.%Y %H:%M": datetime.now().strftime(f),
        "eposta_gonder": golden_eposta_gonder,
    }
    env.update(gui_env())
    return env


ERR_TR = {"NameError": "tanımsız isim", "ZeroDivisionError": "sıfıra bölme",
          "TypeError": "tür hatası", "ValueError": "değer hatası",
          "IndexError": "sıra numarası aralık dışı", "KeyError": "anahtar bulunamadı",
          "FileNotFoundError": "dosya bulunamadı", "AttributeError": "özellik bulunamadı"}


def rapor(e):
    if isinstance(e, GoldenError):
        print("✖ Satır %s: %s" % (e.line, e))
    elif isinstance(e, SyntaxError):
        print("✖ Satır %s: söz dizimi hatası (%s)" % (e.lineno, e.msg))
    else:
        tb = traceback.extract_tb(e.__traceback__)
        ln = next((f.lineno for f in reversed(tb) if f.filename == "<golden>"), "?")
        print("✖ Satır %s: %s — %s" % (ln, ERR_TR.get(type(e).__name__, type(e).__name__), str(e).replace("gui_env.<locals>.", "")))


def run_file(path):
    """Alt süreçte çalışır: editör çıktıyı/girişi pipe ile bağlar."""
    sys.stdout = sys.stderr = open(1, "w", encoding="utf-8", buffering=1, closefd=False)
    sys.stdin = open(0, "r", encoding="utf-8", closefd=False)
    try:
        env = make_env()
        exec(compile(transpile(Path(path).read_text("utf-8")), "<golden>", "exec"), env)
        env["_G"].finish()
        return 0
    except SystemExit:
        return 0
    except Exception as e:
        rapor(e)
        return 1


# ============================================================ EDİTÖR
SURUM = "1.6"
BG, PANEL, GOLD, TEXT = "#0b0b0b", "#151515", "#FFC400", "#F2E8C9"
KW = {"eğer", "ise", "yoksa", "değilse", "döngü", "den", "kadar", "adım", "her", "içinde",
      "tekrarla", "iken", "kır", "devam", "fonksiyon", "döndür", "sınıf", "dene", "hata",
      "sonunda", "bitir", "satır", "içe_al", "değer", "ve", "veya", "değil", "doğru", "yanlış", "boş"}
CMDS = {"yaz", "oku", "sayıoku", "zamanlayıcı"} | CMD_FUNCS | WIDGETS | NAME_CMDS
BUILT = {k for k in make_env() if not k.startswith("_")}
STARTERS = {"eğer", "döngü", "her", "tekrarla", "iken", "fonksiyon", "sınıf", "dene", "satır"}
MIDS = {"değilse", "yoksa", "hata", "sonunda"}
HL = re.compile(r'''(?P<s>"(?:\\.|[^"\\\n])*"?|'(?:\\.|[^'\\\n])*'?)|(?P<c>#[^\n]*)'''
                r'''|(?P<n>\b\d+(?:\.\d+)?\b)|(?P<w>[^\W\d]\w*)''')

SNIPS = [
    ("yaz", 'yaz "Merhaba Golden!"'),
    ("oku (metin)", 'oku ad "Adın ne? "'),
    ("sayıoku (sayı)", 'sayıoku sayı "Bir sayı: "'),
    ("değer", "değer x = 10"),
    ("eğer / değilse", 'eğer x > 5 ise\n  yaz "büyük"\ndeğilse\n  yaz "küçük"\nbitir'),
    ("yoksa eğer", 'eğer x > 5 ise\n  yaz "A"\nyoksa eğer x > 2 ise\n  yaz "B"\nbitir'),
    ("döngü", "döngü i 1 den 10 kadar\n  yaz i\nbitir"),
    ("her ... içinde", "her öge içinde [1, 2, 3]\n  yaz öge\nbitir"),
    ("tekrarla", 'tekrarla 3\n  yaz "Golden"\nbitir'),
    ("iken", "değer n = 0\niken n < 3\n  yaz n\n  n += 1\nbitir"),
    ("fonksiyon", "fonksiyon topla a b\n  döndür a + b\nbitir\nyaz topla(2, 3)"),
    ("dene / hata", 'dene\n  yaz 10 / 0\nhata e\n  yaz "Hata:", e\nbitir'),
    ("sınıf", "sınıf Kedi\n  fonksiyon __init__(self, ad)\n    self.ad = ad\n  bitir\nbitir"),
    ("bekle", "bekle 1"),
    ("rastgele", "yaz rastgele(1, 100)"),
    ("tarih", "yaz tarih()"),
    ("dosya_yaz / oku", 'dosya_yaz("not.txt", "Merhaba")\nyaz dosya_oku("not.txt")'),
    ("— UYGULAMA —", ""),
    ("pencere", 'pencere "Uygulamam", 400, 300'),
    ("etiket", 'etiket yazı "Merhaba"'),
    ("düğme", 'düğme btn "Tıkla" tıklandı\n\nfonksiyon tıklandı\n  mesaj "Tıkladın!"\nbitir'),
    ("giriş", 'giriş kutu "ipucu"'),
    ("metinalanı", 'metinalanı notlar "Notlarını yaz...", 8'),
    ("onay", 'onay kutucuk "Kabul ediyorum"'),
    ("kaydırıcı", "kaydırıcı hız 0, 100"),
    ("listekutusu", 'listekutusu meyveler "Elma", "Armut"'),
    ("satır (yan yana)", 'satır\n  düğme a "A" fa\n  düğme b "B" fb\nbitir'),
    ("ayarla / al", 'ayarla yazı, "Yeni metin"\nyaz al(kutu)'),
    ("ekle (liste)", 'ekle meyveler, "Muz"'),
    ("renk", 'renk yazı, "#FFC400", "#000000"'),
    ("mesaj", 'mesaj "Merhaba!"'),
    ("soru", 'eğer soru("Emin misin?") ise\n  yaz "Evet"\nbitir'),
    ("zamanlayıcı", "zamanlayıcı 1000 saniye_say"),
    ("göster", "göster"),
    ("— ARAÇLAR —", ""),
    ("temizle", "temizle"),
    ("bip", "bip"),
    ("içe_al", "içe_al os"),
]

SAMPLE_APP = '''# Golden ile uygulama yapmak: Sayaç
pencere "Golden Sayaç", 340, 300
değer sayı = 0

etiket başlık "Golden Sayaç"
etiket sonuç "Sayı: 0"
giriş ad "Adını yaz"

satır
  düğme artır_btn "+ Artır" artır
  düğme sıfır_btn "Sıfırla" sıfırla
bitir

düğme selam_btn "Selam ver" selam

fonksiyon artır
  global sayı
  sayı += 1
  ayarla sonuç, "Sayı: " + metin(sayı)
bitir

fonksiyon sıfırla
  global sayı
  sayı = 0
  ayarla sonuç, "Sayı: 0"
bitir

fonksiyon selam
  eğer al(ad) == "" ise
    mesaj "Önce adını yaz!"
  değilse
    mesaj "Merhaba " + al(ad) + "!"
  bitir
bitir

göster
'''

SAMPLE = '''# Golden'a hoş geldin!  F5 ile çalıştır.
oku isim "Adın ne? "
yaz "Merhaba,", isim, "!"

fonksiyon kare x
  döndür x * x
bitir

döngü i 1 den 5 kadar
  yaz i, "->", kare(i)
bitir

eğer rastgele(1, 6) > 3 ise
  yaz "Şanslı gün!"
değilse
  yaz "Bir dahaki sefere."
bitir
'''


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Golden Editör")
        self.geometry("1280x780")
        self.configure(bg=BG)
        self.path, self.proc, self.dirty, self.killed, self.tmp, self._job = None, None, False, False, None, None
        self.q = queue.Queue()
        fam = tkfont.families()
        face = next((f for f in ("Cascadia Code", "Consolas", "DejaVu Sans Mono") if f in fam), "Courier")
        self.f = tkfont.Font(family=face, size=12)
        self.fb = tkfont.Font(family=face, size=12, weight="bold")
        self.fi = tkfont.Font(family=face, size=12, slant="italic")
        self.ui()
        self.set_text(SAMPLE)
        self.after(40, self.pump)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------------------------------------------------- arayüz
    def btn(self, parent, text, cmd, accent=False):
        bg, fg, hov = (GOLD, "#000", "#FFD84D") if accent else ("#1e1e1e", GOLD, "#2e2e2e")
        b = tk.Label(parent, text=text, bg=bg, fg=fg, padx=14, pady=6, cursor="hand2",
                     font=("Segoe UI", 10, "bold"))
        b.bind("<Enter>", lambda e: b.config(bg=hov))
        b.bind("<Leave>", lambda e: b.config(bg=bg))
        b.bind("<Button-1>", lambda e: cmd())
        return b

    def ui(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        for o in ("Vertical", "Horizontal"):
            st.configure(o + ".TScrollbar", background="#3a3000", troughcolor=BG, bordercolor=BG,
                         arrowcolor=GOLD, lightcolor="#3a3000", darkcolor="#3a3000")
            st.map(o + ".TScrollbar", background=[("active", GOLD)])
        top = tk.Frame(self, bg=PANEL)
        top.pack(fill="x")
        tk.Label(top, text="◆ GOLDEN EDİTÖR", bg=PANEL, fg=GOLD, font=("Segoe UI", 13, "bold"),
                 padx=14).pack(side="left")
        for t, c, a in (("Yeni", self.new, 0), ("Aç", self.open, 0), ("Örnek App", self.example, 0), ("Kaydet", self.save, 0),
                        ("Farklı Kaydet", lambda: self.save(True), 0), ("▶  Çalıştır  F5", self.run, 1),
                        ("■  Durdur", self.stop, 0)):
            self.btn(top, t, c, a).pack(side="left", padx=3, pady=6)
        self.stat = tk.Label(self, bg=PANEL, fg="#8a7a3a", anchor="w", padx=12, font=("Segoe UI", 9))
        self.stat.pack(side="bottom", fill="x")
        # sağ: komut paneli
        side = tk.Frame(self, bg=PANEL, width=230)
        side.pack(side="right", fill="y")
        side.pack_propagate(False)
        tk.Label(side, text="KOMUTLAR  (çift tıkla)", bg=PANEL, fg=GOLD, font=("Segoe UI", 9, "bold"),
                 pady=8).pack(fill="x")
        self.lb = tk.Listbox(side, bg=PANEL, fg=TEXT, selectbackground=GOLD, selectforeground="#000",
                             borderwidth=0, highlightthickness=0, activestyle="none", font=self.f)
        for n, _ in SNIPS:
            self.lb.insert("end", "  " + n)
        lsb = ttk.Scrollbar(side, command=self.lb.yview)
        self.lb.config(yscrollcommand=lsb.set)
        lsb.pack(side="right", fill="y", pady=(0, 6))
        self.lb.pack(fill="both", expand=True, padx=(6, 0), pady=(0, 6))
        self.lb.bind("<Double-Button-1>", self.insert_snip)
        # orta: editör + konsol
        pw = tk.PanedWindow(self, orient="vertical", bg=BG, sashwidth=6, sashrelief="flat", borderwidth=0)
        pw.pack(fill="both", expand=True)
        ef = tk.Frame(pw, bg=BG)
        self.ln = tk.Text(ef, width=5, bg=PANEL, fg="#6f6a55", font=self.f, borderwidth=0, padx=6, pady=6,
                          highlightthickness=0, state="disabled", takefocus=0, cursor="arrow", wrap="none")
        self.ln.tag_configure("r", justify="right")
        self.ln.pack(side="left", fill="y")
        self.ed = tk.Text(ef, bg=BG, fg=TEXT, insertbackground=GOLD, selectbackground="#5a4a00",
                          font=self.f, undo=True, wrap="none", borderwidth=0, highlightthickness=0,
                          padx=10, pady=6, insertwidth=2)
        sb = ttk.Scrollbar(ef, command=lambda *a: (self.ed.yview(*a), self.ln.yview(*a)))
        self.sb = sb
        self.ed.config(yscrollcommand=lambda a, b: (sb.set(a, b), self.ln.yview_moveto(a)))
        sb.pack(side="right", fill="y")
        self.ed.pack(side="left", fill="both", expand=True)
        for tag, kw in (("cur", dict(background="#15130a")), ("kw", dict(foreground=GOLD, font=self.fb)),
                        ("cmd", dict(foreground="#FF9F1C", font=self.fb)), ("bi", dict(foreground="#FFE08A")),
                        ("num", dict(foreground="#FFB86B")), ("str", dict(foreground="#8FE3A0")),
                        ("com", dict(foreground="#6f6a55", font=self.fi))):
            self.ed.tag_configure(tag, **kw)
        pw.add(ef, minsize=200, stretch="always")
        cf = tk.Frame(pw, bg="#050505")
        tk.Label(cf, text="  ▸ ÇIKTI", bg=PANEL, fg=GOLD, anchor="w", font=("Segoe UI", 9, "bold")).pack(fill="x")
        row = tk.Frame(cf, bg=PANEL)
        row.pack(side="bottom", fill="x")
        tk.Label(row, text=" ›", bg=PANEL, fg=GOLD, font=self.fb).pack(side="left")
        self.inp = tk.Entry(row, bg=PANEL, fg=GOLD, insertbackground=GOLD, borderwidth=0,
                            highlightthickness=0, font=self.f)
        self.inp.pack(side="left", fill="x", expand=True, padx=6, pady=6)
        self.inp.bind("<Return>", self.send)
        self.con = tk.Text(cf, bg="#050505", fg=TEXT, font=self.f, borderwidth=0, highlightthickness=0,
                           padx=10, pady=4, state="disabled", height=10, wrap="word")
        self.con.pack(fill="both", expand=True)
        self.con.tag_configure("err", foreground="#FF6B6B")
        self.con.tag_configure("info", foreground="#8a7a3a")
        self.con.tag_configure("inp", foreground=GOLD)
        pw.add(cf, minsize=120, height=230)
        # tuşlar
        self.ed.bind("<<Modified>>", self.on_mod)
        self.ed.bind("<Return>", self.on_return)
        self.ed.bind("<Tab>", lambda e: (self.ed.insert("insert", "  "), "break")[1])
        for ev in ("<KeyRelease>", "<ButtonRelease-1>"):
            self.ed.bind(ev, self.on_cursor)
        for k, c in (("<F5>", self.run), ("<Control-s>", self.save), ("<Control-o>", self.open),
                     ("<Control-n>", self.new), ("<Control-period>", self.stop),
                     ("<Control-S>", lambda: self.save(True))):
            self.bind(k, lambda e, c=c: c())
        self.bind("<Control-y>", lambda e: self.ed.edit_redo())

    # ---------------------------------------------------------- düzenleme
    def on_return(self, e):
        t = self.ed
        line = t.get("insert linestart", "insert lineend")
        ind = len(line) - len(line.lstrip(" "))
        w = (line.split() or [""])[0]
        new = ind + 2 if w in STARTERS else ind
        if w == "bitir" or w in MIDS:
            fix = max(0, ind - 2)
            t.delete("insert linestart", "insert linestart+%dc" % ind)
            t.insert("insert linestart", " " * fix)
            new = fix if w == "bitir" else fix + 2
        t.insert("insert", "\n" + " " * new)
        t.see("insert")
        return "break"

    def on_mod(self, e=None):
        if self.ed.edit_modified():
            self.dirty = True
            self.ed.edit_modified(False)
            if self._job:
                self.after_cancel(self._job)
            self._job = self.after(120, self.refresh_view)
            self.on_cursor()

    def refresh_view(self):
        t = self.ed
        for tag in ("kw", "cmd", "bi", "num", "str", "com"):
            t.tag_remove(tag, "1.0", "end")
        lines = t.get("1.0", "end-1c").split("\n")
        for ln, line in enumerate(lines, 1):
            for m in HL.finditer(line):
                k = m.lastgroup
                if k == "w":
                    w = m.group()
                    k = "kw" if w in KW else "cmd" if w in CMDS else "bi" if w in BUILT else None
                    if not k:
                        continue
                else:
                    k = {"s": "str", "c": "com", "n": "num"}[k]
                t.tag_add(k, "%d.%d" % (ln, m.start()), "%d.%d" % (ln, m.end()))
        self.ln.config(state="normal")
        self.ln.delete("1.0", "end")
        self.ln.insert("1.0", "\n".join(map(str, range(1, len(lines) + 1))), "r")
        self.ln.config(state="disabled")
        self.ln.yview_moveto(t.yview()[0])

    def on_cursor(self, e=None):
        l, c = self.ed.index("insert").split(".")
        self.ed.tag_remove("cur", "1.0", "end")
        self.ed.tag_add("cur", l + ".0", l + ".0 lineend+1c")
        name = os.path.basename(self.path) if self.path else "adsız.gld"
        mark = " *" if self.dirty else ""
        self.stat.config(text="Satır %s, Sütun %d     |     %s%s     |     F5: çalıştır   Ctrl+S: kaydet     |     sürüm %s" % (l, int(c) + 1, name, mark, SURUM))
        self.title("Golden Editör — %s%s" % (name, mark))

    def insert_snip(self, e=None):
        s = self.lb.curselection()
        if not s or not SNIPS[s[0]][1]:
            return
        line = self.ed.get("insert linestart", "insert lineend")
        pad = " " * (len(line) - len(line.lstrip(" ")))
        self.ed.insert("insert", SNIPS[s[0]][1].replace("\n", "\n" + pad))
        self.ed.focus_set()

    # ---------------------------------------------------------- dosya
    def set_text(self, txt):
        self.ed.delete("1.0", "end")
        self.ed.insert("1.0", txt)
        self.ed.edit_reset()
        self.ed.edit_modified(False)
        self.dirty = False
        self.refresh_view()
        self.on_cursor()

    def discard_ok(self):
        if not self.dirty:
            return True
        r = messagebox.askyesnocancel("Golden Editör", "Kaydedilmemiş değişiklikler var. Kaydedilsin mi?")
        return False if r is None else (self.save() if r else True)

    def new(self):
        if self.discard_ok():
            self.path = None
            self.set_text("# Yeni Golden programı\n")

    def example(self):
        if self.discard_ok():
            self.path = None
            self.set_text(SAMPLE_APP)

    def open(self):
        if not self.discard_ok():
            return
        p = filedialog.askopenfilename(filetypes=[("Golden dosyası", "*.gld"), ("Tüm dosyalar", "*.*")])
        if not p:
            return
        try:
            txt = Path(p).read_text("utf-8")
        except UnicodeDecodeError:
            txt = Path(p).read_text("cp1254", errors="replace")
        self.path = p
        self.set_text(txt)

    def save(self, as_new=False):
        p = self.path
        if as_new or not p:
            p = filedialog.asksaveasfilename(defaultextension=".gld",
                                             filetypes=[("Golden dosyası", "*.gld"), ("Tüm dosyalar", "*.*")])
        if not p:
            return False
        with open(p, "w", encoding="utf-8", newline="\n") as f:
            f.write(self.ed.get("1.0", "end-1c"))
        self.path, self.dirty = p, False
        self.on_cursor()
        return True

    def on_close(self):
        if self.discard_ok():
            self.stop(True)
            self.destroy()

    # ---------------------------------------------------------- çalıştırma
    def out(self, text, tag=None):
        c = self.con
        c.config(state="normal")
        if "\f" in text:
            c.delete("1.0", "end")
            text = text.rsplit("\f", 1)[1]
        for part in re.findall(r".*?\n|.+$", text):
            c.insert("end", part, "err" if part.startswith("✖") else tag)
        c.see("end")
        c.config(state="disabled")

    def run(self):
        self.stop(True)
        fd, self.tmp = tempfile.mkstemp(suffix=".gld")
        os.write(fd, self.ed.get("1.0", "end-1c").encode("utf-8"))
        os.close(fd)
        cmd = [sys.executable] + ([] if getattr(sys, "frozen", False) else [os.path.abspath(__file__)]) + ["--run", self.tmp]
        env = dict(os.environ, PYTHONUNBUFFERED="1", PYTHONIOENCODING="utf-8")
        self.con.config(state="normal")
        self.con.delete("1.0", "end")
        self.con.config(state="disabled")
        self.out("▶ %s çalışıyor...\n" % (os.path.basename(self.path) if self.path else "adsız.gld"), "info")
        self.killed = False
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     env=env, cwd=os.path.dirname(self.path) if self.path else None,
                                     creationflags=0x08000000 if os.name == "nt" else 0)
        threading.Thread(target=self.reader, args=(self.proc,), daemon=True).start()
        self.inp.focus_set()

    def reader(self, proc):
        dec = codecs.getincrementaldecoder("utf-8")("replace")
        while True:
            b = os.read(proc.stdout.fileno(), 4096)
            if not b:
                break
            self.q.put(("out", proc, dec.decode(b)))
        proc.wait()
        self.q.put(("end", proc, ""))

    def pump(self):
        try:
            while True:
                kind, proc, text = self.q.get_nowait()
                if proc is not self.proc:
                    continue
                if kind == "out":
                    self.out(text)
                else:
                    self.out("\n■ %s\n" % ("Durduruldu." if self.killed else "Program bitti (kod %s)." % proc.returncode), "info")
                    self.proc = None
        except queue.Empty:
            pass
        self.after(40, self.pump)

    def stop(self, silent=False):
        if self.proc and self.proc.poll() is None:
            self.killed = True
            self.proc.kill()
        if silent:
            self.proc = None

    def send(self, e=None):
        t = self.inp.get()
        self.inp.delete(0, "end")
        if self.proc and self.proc.poll() is None:
            self.out(t + "\n", "inp")
            try:
                self.proc.stdin.write((t + "\n").encode("utf-8"))
                self.proc.stdin.flush()
            except Exception:
                pass


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "--run":
        sys.exit(run_file(sys.argv[2]))
    App().mainloop()
